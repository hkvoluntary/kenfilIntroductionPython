import math

def round_down(f):
    return math.floor(f)

def round_up(f):
    return math.ceil(f)