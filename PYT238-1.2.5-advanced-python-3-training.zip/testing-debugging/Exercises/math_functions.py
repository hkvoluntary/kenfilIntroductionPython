import math

def round_down(f):
    return int(f) # doesn't work for negative numbers

def round_up(f):
    return math.ceil(f)