class Die:
    pass