from Plane1 import Plane

class Jet(Plane):
    def __init__(self):
        self.planes = []
        super().__init__()