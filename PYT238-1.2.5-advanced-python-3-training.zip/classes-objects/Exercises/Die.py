class Die:
    def __init__(self, sides=6):
        self.sides = sides
        
    # add a roll() method