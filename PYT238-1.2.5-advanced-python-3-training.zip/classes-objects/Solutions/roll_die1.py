from Die1 import Die

die = Die()

roll = die.roll()
print(roll)