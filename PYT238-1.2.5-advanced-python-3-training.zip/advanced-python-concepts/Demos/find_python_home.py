import sys
import os

python_home = os.path.dirname(sys.executable)
print(python_home)